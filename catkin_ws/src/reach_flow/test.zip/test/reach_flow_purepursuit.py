#!/usr/bin/env python
#author: qinlin@andrew.cmu.edu
#import rospy
#from std_msgs.msg import String
import os
import subprocess
from PIL import Image
from mpmath import *
import copy
from interval import interval, inf, imath
from transformations import *

#amankh
import rospy
import ackermann_msgs.msg
import geometry_msgs.msg
import nav_msgs.msg
#import matplotlib.pyplot as plt
#import matplotlib.image as mpimg
import numpy as np

k = 1.5
kp = 1
L = 0.257
Lfc = 0.3


class Nodo(object):
    def __init__(self):
        self.pos_x = 0
        self.pos_y = 0
        self.pos_z = 0
        self.v_d = 0.7
        self.current_speed = 0
        self.command_speed = 0
        self.psi = 0
        self.loop_rate = rospy.Rate(2)
        self.yaw = 0
        #self.k = 3 #look-ahead parameter
        #self.kp = 1 #velocity propotional control
        #self.L = 0.257 #length of vehicle, 0.257?
        #self.Lfc = 0.3 #look ahead distance
        #self.L_f = 0.115
        self.psi = 0
        #self.ctr_action = ackermann_msgs.msg.AckermannDriveStamped()
        self.waypoint_counter = 0
        rospy.Subscriber("ekf_localization/odom", nav_msgs.msg.Odometry, self.stateCallback)
        #rospy.Subscriber("commands/keyboard", ackermann_msgs.msg.AckermannDriveStamped, self.actionCallback)
        #rospy.Subscriber("aa_planner/waypoints", geometry_msgs.msg.Point, self.waypointCallback)
        #self.action_publisher = rospy.Publisher("commands/keyboard_test",ackermann_msgs.msg.AckermannDriveStamped, queue_size=10)

        self.waypoints_x = list(np.arange(0, 20, 0.5))
        self.waypoints_y = [0 for i in self.waypoints_x]
        self.loop_rate.sleep()
	self.action_publisher = rospy.Publisher("commands/keyboard",ackermann_msgs.msg.AckermannDriveStamped, queue_size=10)

    def stateCallback(self,state_t):
        self.pos_x = state_t.pose.pose.position.x#same to odom.pose.pose.position.x?
        self.pos_y = state_t.pose.pose.position.y
        self.yaw = euler_from_quaternion([self.pos_x,self.pos_y,state_t.pose.pose.orientation.z,state_t.pose.pose.orientation.w])[2]
        self.x_dot = state_t.twist.twist.linear.x
        self.y_dot = state_t.twist.twist.linear.y
        self.current_speed = np.sqrt(np.square(self.x_dot)+np.square(self.y_dot))
        self.psi = self.yaw


    def actionCallback(self,action_t):
        self.speed = action_t.drive.speed

    #def waypointCallback(self,waypoint_t):
    #    #waypoint_curvature = waypoint_t.z
    #    waypoint_x = waypoint_t.x
    #    waypoint_y = waypoint_t.y
    def start(self):
        while not rospy.is_shutdown():
           # if self.pos_x >= x_d:
           #     ctr_action.drive.speed = 0
           #     ctr_action.drive.steering_angle = 0
           #     self.action_publisher.publish(ctr_action)
           #     break
            lastIndex = len(self.waypoints_x) - 1
            target_ind = calc_target_index(self.pos_x, self.pos_y, self.waypoints_x, self.waypoints_y, self.current_speed)
            
            #while lastIndex > target_ind:
            ctr_action = ackermann_msgs.msg.AckermannDriveStamped()
            if lastIndex > target_ind:
                ai = PControl(self.v_d, self.current_speed)
                di, target_ind = pure_pursuit_control(self.pos_x, self.pos_y, self.psi, self.waypoints_x, self.waypoints_y, self.current_speed, target_ind)
                #self.command_speed = self.current_speed + ai
                self.command_speed = 0.0
                #ctr_action.drive.steering_angle = di
                ctr_action.drive.steering_angle = 0
            else:
                self.command.speed = 0.0
                ctr_action.drive.steering_angle = 0

            
            ctr_action.drive.speed = self.command_speed # speed in m/s, the car doesn't move well below 0.6
            
            self.action_publisher.publish(ctr_action)

            #print 'alpha: '+str(alpha)
            print 'psi: '+str(self.psi)
            print 'current_speed: '+str(self.current_speed)
            print 'position_x: '+str(self.pos_x)+' / '+str(self.waypoints_x[target_ind])
            print 'position_y: '+str(self.pos_y)+' / '+str(self.waypoints_y[target_ind])

            print 'angle_command: '+str(ctr_action.drive.steering_angle)
            print 'speed_command: '+str(ctr_action.drive.speed)+'\n'
 
            self.loop_rate.sleep()
    
def calc_target_index(pos_x, pos_y, way_points_x, way_points_y, v):
    global k
    global Lfc
    dx = [pos_x - icx for icx in way_points_x]
    dy = [pos_y - icy for icy in way_points_y]
    d = [abs(math.sqrt(idx ** 2 + idy ** 2)) for (idx, idy) in zip(dx, dy)]
    ind = d.index(min(d))
    L = 0.0

    Lf = k * v + Lfc

    while Lf > L and (ind + 1) < len(way_points_x):
        dx = way_points_x[ind + 1] - way_points_x[ind]
        dy = way_points_y[ind + 1] - way_points_y[ind]
        L += math.sqrt(dx ** 2 + dy ** 2)
        ind += 1

    return ind
def PControl(target, current):
    global kp
    a = kp * (target - current)

    return a

def pure_pursuit_control(pos_x, pos_y, psi, way_points_x, way_points_y, v, pind):
    global k
    global Lfc
    ind = calc_target_index(pos_x, pos_y, way_points_x, way_points_y, v)

    if pind >= ind:
        ind = pind

    if ind < len(way_points_x):
        tx = way_points_x[ind]
        ty = way_points_y[ind]
    else:
        tx = cx[-1]
        ty = cy[-1]
        ind = len(way_points_x) - 1

    #alpha = math.atan2(ty - state.y, tx - state.x) - state.yaw
    alpha = np.arctan((ty-pos_y)/(tx-pos_x))-psi

    if v > 0:
        alpha = math.pi - alpha

    Lf = k * v + Lfc

    delta = np.arctan(2*L*np.sin(alpha)/Lf)


    if delta >= np.pi/3:
        delta = np.pi/3
    elif delta <= -np.pi/3:
        delta = -np.pi/3
    else:
        delta = delta

    return delta, ind


def writeFlowstarFile(current_waypoint_x_d, current_waypoint_y_d, current_waypoint_v_d, av0):
    '''
        Function: Write target point: x_d, y_d, target velocity: v_d, and initial state of auxiliary variable into the template of flow* file
        Input: none
        Output: new flow* file
    '''
    filename = 'flowstar-2.1.0/model/RC_kinematic_purepursuit_template'
    with open(filename+'.model') as f:
        file_str = f.read()
    file_str = file_str.replace('X_D', str(current_waypoint_x_d))
    file_str = file_str.replace('Y_D', str(current_waypoint_y_d))
    file_str = file_str.replace('V_D', str(current_waypoint_v_d))
    #av0 = initial_state_interval()
    file_str = file_str.replace('AV0', str(av0[0][0]))
    file_str = file_str.replace('AV1', str(av0[0][1]))
    with open(filename+'_new.model', "w") as f:
        f.write(file_str)
def executeFlowstar():
    '''
        Function: Execute reachability computation by calling flow*
        Input: none
        Output: none
    '''
    os.system('cd flowstar-2.1.0;'+'./flowstar < '+'model/RC_kinematic_purepursuit_template_new.model')
def visulization():
    '''
        Function: Visualize reachability results
        Input: none
        Output: none
    '''    
    os.system('cd flowstar-2.1.0/outputs;'+'gnuplot "RC_kinematic_purepursuit.plt"')
    imgplot = plt.imshow(mpimg.imread('flowstar-2.1.0/outputs/images/RC_kinematic_purepursuit.eps'))
    plt.show(block=False)
    plt.pause(3)
    plt.close()
def initial_state_interval(v, pos_x, pos_y, psi, x_d_0=interval[1, 1], y_d_0=interval[1, 1]):
    v_0 = v + interval[0, 0.01]
    pos_x_0 = pos_x + interval[0, 0.01]
    pos_y_0 = pos_y + interval[0, 0.01]
    psi_0 = psi + interval[0, 0.01]
    #x_d_0 = interval[1, 1]
    #y_d_0 = interval[1, 1]
    av = (lambda v, psi, x_d, y_d, pos_x, pos_y: (-1 * v * imath.sinpi(psi) * x_d + y_d * v * imath.cospi(psi) - pos_y * v * imath.cospi(psi))/((x_d - pos_x)**2+(y_d - pos_y)**2))\
    (v_0, psi_0, x_d_0, y_d_0, pos_x_0, pos_y_0)
    return av
if __name__ == '__main__':
    #, pos_y, pos_z, psi, q, yaw, x_dot, y_dot, yaw_dot
    rospy.init_node('reach_flow')
    my_node = Nodo()
    my_node.start()


