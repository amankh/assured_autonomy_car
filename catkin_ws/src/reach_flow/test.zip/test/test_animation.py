#import math
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle




def init():
    line.set_data([], [])
    return line,

def isfloat(value):
    try:
        float(value)
        return True
    except ValueError:
        return False

def animate(i):
    global xc
    global yc
    global width
    global height
    global x_min
    global x_max
    global y_min
    global y_max
    #if i <= len(xc)-1:
    #print xc[i], yc[i], width[i], height[i]
    plt.gca().add_patch(plt.Rectangle((xc[i], yc[i]), width[i], height[i], fill=False, edgecolor='g'))
    #print type(xc[i]), type(yc[i]), type(width[i]), type(height[i])
    x_min = min(x_min, xc[i]-0.5*width[i])
    x_max = max(x_max, xc[i]+0.5*width[i])
    y_min = min(y_min, yc[i] - 0.5*height[i]-0.01)
    y_max = max(y_max, yc[i] + 0.5*height[i]+0.01)


    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max)
    #ax = plt.axes(xlim=(0, xc[i] + width[i]+1), ylim=(yc[i] - height[i]-0.1, yc[i] + height[i]+0.1))
    return xc
#i += 1


data = open('flow.txt','r').read()
lines = data.split('\n')
#print lines
xc = []
yc = []
width = []
height = []
#i = 0
for line in lines:
    a = line.strip().split(' ') # Delimiter is comma
    if isfloat(a[0])== True and isfloat(a[1])== True:
        xc.append(float(a[0]))
        yc.append(float(a[1]))
        width.append(float(a[2]))
        height.append(float(a[3]))
fig = plt.figure()
ax = plt.axes(xlim=(0, 10), ylim=(-0.1, 0.1))
line, = ax.plot([], [], lw=3)
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Reachable states')
x_min = xc[0]-0.5*width[0]
x_max = xc[0]+0.5*width[0]
y_min = yc[0] - 0.5*height[0]
y_max = yc[0] + 0.5*height[0]
#print len(xc)
ani = animation.FuncAnimation(fig, animate, interval=1, frames=4000, blit=False, repeat=False)
plt.show()
#ani.save('the_movie.mp4', writer = 'mencoder', fps=50)
