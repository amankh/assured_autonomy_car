#ifndef LINESEARCH_H
#define LINESEARCH_H

#include "iLQG.h"

int line_search(tOptSet *o, int iter);

#endif /* LINESEARCH_H */
